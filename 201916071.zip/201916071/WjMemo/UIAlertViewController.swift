//
//  UIAlertViewController.swift
//  201916071
//
//  Created by 203a21 on 2022/06/09.
//

import UIKit
// 메모를 입력하지않고 저장했을 경우에 나타나는 Alert기능을 구현했습니다.
extension UIViewController  {
    func alert(title: String = "알림", message: String)   {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "확인합니다.", style: .default, handler: nil)
        alert.addAction(okAction)
        
        present(alert, animated: true, completion: nil)
    }
}
