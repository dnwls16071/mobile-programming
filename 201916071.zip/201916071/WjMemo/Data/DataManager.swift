//
//  DataManager.swift
//  201916071
//
//  Created by 203a21 on 2022/06/10.
//

import Foundation
import CoreData // 

// DataManager라는 새로운 클래스 안에 메모장에서 사용될 수 있는 여러가지 기능을 구현했습니다.
class DataManager   {   // 어플 전체에서 하나의 인스턴스를 공유할 수 있도록 하는 코드입니다.
    
    static let shared = DataManager()
    private init()  {}
    
    var mainContext: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    var memoList = [Memo]()
    
    // 메모장에 저장한 데이터를 정렬할 수 있는 기능을 구현한 코드
    func fetchMemo() {
        let request: NSFetchRequest<Memo> = Memo.fetchRequest()
        let sortByDateDesc = NSSortDescriptor(key: "insertDate", ascending: false)
        request.sortDescriptors = [sortByDateDesc]
        
        do  {
            memoList = try mainContext.fetch(request)
        }   catch   {
            print(error)
        }
    }
    
    // 메모장에 메모를 추가할 수 있는 기능을 구현한 코드
    func addNewMemo(_ memo:String?) {
        let newMemo = Memo(context: mainContext)
        newMemo.content = memo
        newMemo.insertDate = Date()
        memoList.insert(newMemo, at: 0)
        saveContext()
    }
    
    // 메모장에서 메모를 삭제할 수 있는 기능을 구현한 코드
    func DeleteMemo(_ memo: Memo?)  {
    if let memo = memo  {
        mainContext.delete(memo)
        saveContext()
        }
    }
    // MARK: - Core Data stack
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "WjMemo")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Saving support
    // 메모장에 메모를 저장할 수 있는 기능을 구현한 코드
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}

