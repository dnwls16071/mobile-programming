//
//  Model.swift
//  WjMemo
//
//  Created by 203a21 on 2022/06/09.
//

import Foundation

// DataManager클래스와 충돌하므로 전부 주석처리했다.
//class Memo  {
//    var content: String
//    var insertDate: Date
//
//    init(content: String)   {
//        self.content = content
//        insertDate = Date()
//    }
//
//    static var dummyMemoList = [
//        Memo(content: "모바일 프로그래밍 기말고사 일정 : 6/17"),
//        Memo(content: "12,13,14장 + 기말고사 프로젝트 제출하기")]
//}
